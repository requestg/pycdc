def SWAP():
    my_array = [
        1,
        2,
        3,
        4,
        5,
        6,
        8]
    i = 1
    j = 3
    my_array[i], my_array[j], my_array[2] = my_array[j], my_array[i], my_array[4]
